const cities = document.querySelectorAll('.city');
let cityInput = "London";
let weather = {
    apiKey:"21a74b6e401d20b033a136aed0089532",
     fetchWeather : function(city){
        fetch("https://api.openweathermap.org/data/2.5/weather?q="
        +city 
        +"&units=metric&appid="
        +this.apiKey)
        .then((response)=> response.json())
        .then((data)=>this.displayWeather(data));
     },
     displayWeather: function(data){
        const {name} = data;
        const {icon , description} =data.weather[0];
        const {temp, humidity} = data.main;
        const { speed } = data.wind;
        const { cloudy } = data.clouds;
        console.log(name,icon,description,temp,humidity,speed,cloudy);
        document.querySelector(".name").innerText = name;
        document.querySelector(".icon").src="https://openweathermap.org/img/wn/"+icon+"@2x.png";
        document.querySelector(".temp").innerText = temp + "°C";
        document.querySelector(".condition").innerText  = description;
        document.querySelector(".humidity").innerText =  humidity + "%";
        document.querySelector(".wind").innerText =  speed +"km/h";
        document.querySelector(".cloud").innerText =  cloudy +"%";
    },
    search:function(){
        this.fetchWeather(document.querySelector(".search").value);
    },
   
};



document.querySelector('.submit').addEventListener("click",function(e){
    if (document.querySelector('.search').value.length == 0){
        alert("Please Enter a city name");
    }
    else{
    
    weather.search();
    document.querySelector('.search').value = "";
    }
    e.preventDefault();
})

document.querySelector('.search').addEventListener("keyup",function(event){
      if(event.key == "Enter"){
          if (document.querySelector('.search').value.length == 0){
            alert("Please Enter a city name");
          }
          else{
          weather.search();
          document.querySelector('.search').value = "";
          } 
      }
      event.preventDefault();
})

cities.forEach((city) => {
    city.addEventListener('click',(e) =>{
        cityInput = e.target.innerText;
        weather.fetchWeather();
    });
    })

    
